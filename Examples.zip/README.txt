#generación de codigo con CMake y CMakeList.txt
#===============================================

1) install CMake a restart the computer: 
	https://cmake.org/download/

#cmake debe ejecutarse en el directorio donde esté CMakeList.txt
2) configure the build:
	cmake -S . -B build

3) build release binaries
	cmake --build build --config Release

3) build debug binaries
	cmake --build build --config Debug


#Para generar los ficheros dll asociados al ejecutable:
#======================================================
#info en https://doc.qt.io/qt-6/windows-deployment.html
#buscador key words: Qt dll windows

1) desde cmd> situarse en el directorio padre de donde se ubique el ejecutable
2) >windeployqt ./exe_dir_file

